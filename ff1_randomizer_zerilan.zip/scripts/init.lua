Tracker:AddItems("items.json")
ScriptHost:LoadScript("scripts/class.lua")
ScriptHost:LoadScript("scripts/custom_item.lua")
--ScriptHost:LoadScript("scripts/toggle.lua")
--ScriptHost:LoadScript("scripts/prog.lua")
ScriptHost:LoadScript("scripts/item_types.lua")
ScriptHost:LoadScript("scripts/logic_common.lua")
--ScriptHost:LoadScript("scripts/create_item.lua")


if not (string.find(Tracker.ActiveVariantUID, "treasure_hunt")) then
	Tracker:AddLayouts("standard/tracker.json")
	Tracker:AddLayouts("standard/broadcast.json")
else
	Tracker:AddLayouts("treasure_hunt/tracker.json")
	Tracker:AddLayouts("treasure_hunt/broadcast.json")
end

