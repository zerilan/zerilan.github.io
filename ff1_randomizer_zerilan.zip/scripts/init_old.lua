--  Load configuration options up front
Tracker:AddItems("items.json")
ScriptHost:LoadScript("scripts/class.lua")
ScriptHost:LoadScript("scripts/custom_item.lua")
ScriptHost:LoadScript("scripts/toggle_item.lua")
--ScriptHost:LoadScript("scripts/create_item.lua")


if not (string.find(Tracker.ActiveVariantUID, "treasure_hunt")) then
	Tracker:AddLayouts("standard/tracker.json")
	Tracker:AddLayouts("standard/broadcast.json")
else
	Tracker:AddLayouts("treasure_hunt/tracker_layout.json")
	Tracker:AddLayouts("standard/broadcast.json")
end
