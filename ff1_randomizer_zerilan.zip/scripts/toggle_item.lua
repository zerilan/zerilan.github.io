﻿ToggleItem = class(CustomItem)

function ToggleItem:init(name, code, image)
    self:createItem(name)
    self.code = code
    self.active = false
    self.ImagePath = image
    self.activeImage = ImageReference:FromPackRelativePath(image)
    self.disabledImage = ImageReference:FromImageReference(self.activeImage, "@disabled")
    self.ItemInstance.PotentialIcon = self.activeImage

    self:updateIcon()    
end

function ToggleItem:setActive(active)
    if active ~= self.active then
        self.active = active
        self:updateIcon()
    end
end

function ToggleItem:updateIcon()
    if self.active then
        self.ItemInstance.Icon = self.activeImage
    else
        self.ItemInstance.Icon = self.disabledImage
    end
end

function ToggleItem:onLeftClick()
    self:setActive(true)
end

function ToggleItem:onRightClick()
    self:setActive(false)
end

function ToggleItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function ToggleItem:providesCode(code)
    if code == self.code and self.active then
        return 1
    end
    return 0
end

PaletteItem = class(CustomItem)

-- PaletteItems are the mutually exclusive items that you use to control what you're putting on a map square
-- There are no properties used on this one since we do not want this item to change by using undo
-- In addition there is no handling for saving and loading since we want it to return to its default state if a save is loaded
-- Extra variables:
-- self.imagePath - Stores the image path used on init for setting the map square

function PaletteItem:init(name,code,image)
	self:createItem(name)
	self.code = code
	self.Active = false
	self.activeImage = ImageReference:FromPackRelativePath(image)
	self.imagePath = image
	self.disabledImage = ImageReference:FromImageReference(self.activeImage, "@disabled")
	self.ItemInstance.PotentialIcon = self.activeImage
	
	self:UpdateIcon()
end

function PaletteItem:UpdateIcon()
	if self.Active then
		self.ItemInstance.Icon = self.activeImage
	else
		self.ItemInstance.Icon = self.disabledImage
	end
end

function PaletteItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function PaletteItem:providesCode(code)
    if code == self.code and self.Active then
        return 1
    end
    return 0
end

function PaletteItem:onLeftClick()
	-- Disable the currently selected palette item if there is one
	if CurrentPalette then
		CurrentPalette.Active = false
		CurrentPalette:UpdateIcon()
	end
	-- The rest here we can just do regardless of if the item is active already or not
	-- "CurrentPalette = self" stores the relative link to our current item for later use
	CurrentPalette = self
    self.Active = true
	-- Since we're not using setProperty we also can't use PropertyChanged() and so have to just push the icon update here.
	self:UpdateIcon()
end

function PaletteItem:onRightClick()
	-- We do need to double check that the user isn't right-clicking another palette item
	-- So check if it's active first before we nil the palette
	if self.Active then
		CurrentPalette = nil
	end
    self.Active = false
	-- Since we're not using setProperty we also can't use PropertyChanged() and so have to just push the icon update here
	self:UpdateIcon()
end

-- Since we're not interested in saving palette state, we make the save function return nothing instead of the default empty table
function PaletteItem:save()
end

local newItem = PaletteItem("test_item","testing","images/items/adamant.png")