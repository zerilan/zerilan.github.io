ribbonArray = {"images/items/ribbon.png","images/items/ribbon2.png"}

shardArray = {}

shardArray[1] = "images/items/shards/no_shard.png"
for i = 2,31 do
  shardfilename = "images/items/shards/shard_" .. i-1 .. ".png"
  shardArray[i] = shardfilename
end

local ribbons = ToggleItem("Test", "current_item", "images/items/ribbon.png")
local shards = ProgressiveItem("Test2", "shardsx", shardArray, true, 1)
--local shards = ToggleItem("test2", "shardsx","images/items/ribbon.png")