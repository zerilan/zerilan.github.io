ProgressiveItem = class(CustomItem)

function ProgressiveItem:init(name, code, imageArray, idxStart, idxMax, canDisable)--, idxStart, idxMax)
    self:createItem(name)
    self.code = code
    self.canDisable = canDisable
    self:setProperty("active", false)
    if self.canDisable == 0 then 
        self:setProperty("active", true)
    end
	self.imageIdx = 1
	if idxStart < 1 and idxStart <= idXMax then
    		self.imageIdx = idxStart
	end
    self.imageArray = imageArray
    self.imageLimit = idxMax
    self.activeImage = ImageReference:FromPackRelativePath(imageArray[idxStart])
    self.disabledImage = ImageReference:FromImageReference(self.activeImage, "@disabled")
    self.ItemInstance.PotentialIcon = self.activeImage
    self:updateIcon()    
end

function ProgressiveItem:setActive(active)
    self:setProperty("active", active)
end

function ProgressiveItem:getActive()
    return self:getProperty("active")
end

function ProgressiveItem:updateIcon()
   --self.activeImage = ImageReference:FromPackRelativePath(self.imageArray[self.imageIdx])
    if self:getActive() then
	if self.imageArray ~= nil then
        self.activeImage = ImageReference:FromPackRelativePath(self.imageArray[self.imageIdx])
	end
        self.ItemInstance.Icon = self.activeImage
    else
        self.ItemInstance.Icon = self.disabledImage
    end
end

function ProgressiveItem:onLeftClick()
        if not self:getActive(true) then
          self:setActive(true)
        elseif self.imageIdx < self.imageLimit then
            self.imageIdx = self.imageIdx + 1
        end
        self.activeImage = ImageReference:FromPackRelativePath(self.imageArray[self.imageIdx])
        self:updateIcon()
    --else
   
    --end
end

function ProgressiveItem:onRightClick()
    if self.imageIdx == 1 and self.canDisable == 1 then
        self:setActive(false)
    elseif self.imageIdx > 1 then 
        self.imageIdx = self.imageIdx - 1
        self.activeImage = ImageReference:FromPackRelativePath(self.imageArray[self.imageIdx])
        self:updateIcon()
    end
end

function ProgressiveItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function ProgressiveItem:providesCode(code)
    if code == self.code and self:getActive() then
        return self.imageIdx
    end
    return 0
end

function ProgressiveItem:advanceToCode(code)
    if code == nil or code == self.code then
        self:setActive(true)
    end
end

function ProgressiveItem:save()
    local saveData = {}
    saveData["active"] = self.getActive()
    return saveData
end

function ProgressiveItem:load(data)
    if data["active"] ~= nil then
        self:setActive(data["active"])
    end
    return true
end

function ProgressiveItem:propertyChanged(key, value)
    self:updateIcon()
end

shardArray = {}

ribbonArray = {"images/items/ribbon.png","images/items/ribbon2.png", "images/items/ribbon3.png"}

shardArray[1] = "images/items/shards/no_shard.png"
for i = 2,31 do
  shardfilename = "images/items/shards/shard_" .. i-1 .. ".png"
  shardArray[i] = shardfilename
end

smallJobArray= {
    "images/items/jobs/ft.png",
    "images/items/jobs/tf.png",
    "images/items/jobs/bb.png",
    "images/items/jobs/rm.png",
    "images/items/jobs/wm.png",
    "images/items/jobs/bm.png",
    "images/items/jobs/no.png"

}

bigJobArray= {
    "images/items/jobs/kn.png",
    "images/items/jobs/nj.png",
    "images/items/jobs/gm.png",
    "images/items/jobs/rw.png",
    "images/items/jobs/ww.png",
    "images/items/jobs/bw.png",
    "images/items/jobs/no.png"

}

job1 = ProgressiveItem("Job one", "job1", smallJobArray, 1,7,0)--,4,20)
job2 = ProgressiveItem("Job2", "job2", smallJobArray, 1,7,0)
job3 = ProgressiveItem("Job3", "job3", smallJobArray, 1,7,0)
job4 = ProgressiveItem("Job4", "job4", smallJobArray, 1,7,0)
local shards = ProgressiveItem("Shards", "shard", shardArray, 1,31)--,4,20)
local ribbons =  ProgressiveItem("Ribbons", "ribbon", ribbonArray, 1, 3,1)


