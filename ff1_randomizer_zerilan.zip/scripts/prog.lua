ProgItem = class(CustomItem)

function ProgItem:init(name, code, images, disable, start)
    self:createItem(name)
    self.code = code
    self:setProperty("active", false)
    self:setProperty("disable",disable)
    self.canDisable = true
    if  not self:getProperty("disable") then
       self:setProperty("active", true)
       self.canDisable = false
    end
    self.imageIdx = start
    self.imageArray = images
    self.imageLimit = 0
    for i,data in pairs(images) do
       self.imageLimit = self.imageLimit + 1
    end
    self.activeImage = ImageReference:FromPackRelativePath(self.imageArray[self.imageIdx])
    self.disabledImage = ImageReference:FromImageReference(self.activeImage, "@disabled")
    self.ItemInstance.PotentialIcon = self.activeImage

    self:updateIcon()    
end

function ProgItem:incrementImageIdx()
   if (self.imageIdx < self.imageLimit) then
      self.imageIdx = self.imageIdx + 1
   else
    self.imageArray = changeToShard(self.imageArray)
   end
end

function ProgItem:decrementImageIdx()
   if (self.imageIdx > 1) then
      self.imageIdx = self.imageIdx - 1
   end
end

function ProgItem:setActive(active)
    self:setProperty("active", active)
    self.code = self.code .. "1"
end

function ProgItem:getActive()
    return self:getProperty("active")
end

function ProgItem:updateIcon()
    if self:getActive() then
        self.ItemInstance.Icon = self.activeImage
    else
        self.ItemInstance.Icon = self.disabledImage
    end
end

function ProgItem:onLeftClick()
    if not self:getActive() then
	self:setActive(true)
    else
        self:incrementImageIdx()
        self.activeImage = ImageReference:FromPackRelativePath(self.imageArray[self.imageIdx])
        self:updateIcon()
    end
end

function ProgItem:onRightClick()
    if not (self.imageIdx == 1) then
       self:decrementImageIdx()
        self.activeImage = ImageReference:FromPackRelativePath(self.imageArray[self.imageIdx])
        self:updateIcon()
    elseif  self.canDisable then
	self:setActive(false)
    end
end

function ProgItem:canProvideCode(code)
    if code == self.code then
        return true
    else
        return false
    end
end

function ProgItem:providesCode(code)
    if code == self.code and self.getActive() then
        return 1
    end
    return 0
end

function ProgItem:provideIdx()
   return self.imageIdx
end

function ProgItem:advanceToCode(code)
    if code == nil or code == self.code then
        self:setActive(true)
    end
end

function ProgItem:save()
    local saveData = {}
    saveData["active"] = self.getActive()
    return saveData
end

function ProgItem:Load(data)
    if data["active"] ~= nil then
        self:setActive(data["active"])
    end
    return true
end

function ProgItem:propertyChanged(key, value)
    self:updateIcon()
end