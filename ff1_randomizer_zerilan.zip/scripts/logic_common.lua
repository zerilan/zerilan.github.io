--function changeToShard()
-- imageArray = "images/items/shards/shard_2.png"
-- if (Tracker:ProviderCountForCode("upgrade") > 0) then
--     imageArray = "images/items/shards/shard_20.png"
-- end
-- return imageArray
--end

function tracker_on_accessibility_updated()
    if Tracker:ProviderCountForCode("upgrade") > 0 then
        job1.imageArray = bigJobArray
        job2.imageArray = bigJobArray
        job3.imageArray = bigJobArray
        job4.imageArray = bigJobArray
        job1:updateIcon()
        job2:updateIcon()
        job3:updateIcon()
        job4:updateIcon()
    else
        job1.imageArray = smallJobArray
        job2.imageArray = smallJobArray
        job3.imageArray = smallJobArray
        job4.imageArray = smallJobArray
        job1:updateIcon()
        job2:updateIcon()
        job3:updateIcon()
        job4:updateIcon()
    end
end